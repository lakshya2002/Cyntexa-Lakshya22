#include<iostream>
#include<math.h>

using namespace std;
void pascals(int n){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cout<<" "<<" ";
			
		}
		cout<<endl;
		int num=pow(11,i-1);
			while(num!=0)
			{
				int digit=num%10;
				num=num/10;
				cout<<digit<<" ";
			}
	}
	
}
int main(){
	pascals(5);
}
