#include<iostream>
using namespace std;
string complement(string b){
	int len = b.length();
	bool ones = false;
	for (int i=len-1; i>=0; i--){
		if(ones){
			if(b[i]=='1'){
				b[i]='0';
			}
			else{
				b[i]='1';
			}
		}
		else{
			if(b[i]=='1'){
				ones = true;
			}
		}
	}
}
int main(){
	string bnum = "1001" ;
	string twocomplement = complement(bnum);
	cout<<twocomplement<<" ";
	}
