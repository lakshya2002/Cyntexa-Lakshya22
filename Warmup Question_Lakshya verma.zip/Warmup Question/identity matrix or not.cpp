#include <iostream>
#include <vector>
using namespace std;

bool isIdentityMatrix(vector<vector<int> >& matrix) {
    if (matrix.size() != matrix[0].size()) {
        return false;
    }

    for (size_t i = 0; i < matrix.size(); ++i) {
        for (size_t j = 0; j < matrix[i].size(); ++j) {
            if (i == j && matrix[i][j] != 1) {
                return false; 
            } else if (i != j && matrix[i][j] != 0) {
                return false; 
            }
        }
    }

    return true;
}

int main() {
    vector<vector<int> > matrix = {
        {1, 0, 0},
        {0, 1, 0},
        {0, 0, 1}};

    if (isIdentityMatrix(matrix)) {
        cout << "The matrix is an Identity matrix." << endl;
    } else {
        cout << "The matrix is not an Identity matrix." << endl;
    }

}

