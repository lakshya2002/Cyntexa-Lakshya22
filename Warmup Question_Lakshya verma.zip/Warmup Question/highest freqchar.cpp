#include <iostream>
#include <unordered_map>
using namespace std;

char findHighestFrequency(string& inputString) {
    std::unordered_map<char, int> charFrequency;

    for (char ch : inputString) {
        charFrequency[ch]++;
    }

    char highestFrequencyChar = '\0'; 
    int maxFrequency = 0;


    for (const auto& pair : charFrequency) {
        if (pair.second > maxFrequency) {
            maxFrequency = pair.second;
            highestFrequencyChar = pair.first;
        }
    }

    return highestFrequencyChar;
}

int main() {
    
}

