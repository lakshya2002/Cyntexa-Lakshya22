#include <iostream>
#include <unordered_set>
using namespace std;

string removeDuplicates(string& inputString) {
    string result;
    unordered_set<char> seenChars;

    for (char ch : inputString) {
        if (seenChars.find(ch) == seenChars.end()) {
            result.push_back(ch);
            seenChars.insert(ch);
        }
    }

    return result;
}

int main() {
    string inputString;
    cout << "Enter a string: ";
    cin>>inputString;

    string result = removeDuplicates(inputString);

    cout << "String after removing duplicates: " << result << endl;
}

