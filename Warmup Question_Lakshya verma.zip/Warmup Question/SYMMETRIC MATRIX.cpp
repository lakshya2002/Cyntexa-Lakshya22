#include <iostream>
#include <vector>

using namespace std;

bool isSymmetricMatrix(const vector<vector<int> >& matrix) {
    if (matrix.size() != matrix[0].size()) {
        return false;
    }

    
    for (size_t i = 0; i < matrix.size(); ++i) {
        for (size_t j = 0; j < matrix[i].size(); ++j) {
            if (matrix[i][j] != matrix[j][i]) {
                return false;
            }
        }
    }

    return true;
}

int main() {
    vector<vector<int> > matrix = {
        {1, 2, 3},
        {2, 4, 5},
        {3, 5, 6}
    };

    if (isSymmetricMatrix(matrix)) {
        cout << "The matrix is a Symmetric matrix." << endl;
    } else {
        cout << "The matrix is not a Symmetric matrix." << endl;
    }

    return 0;
}

