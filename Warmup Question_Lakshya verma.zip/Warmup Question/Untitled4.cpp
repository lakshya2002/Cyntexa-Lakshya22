#include<iostream>
using namespace std;
int btod(int binary){
	int decimal=0, base=1;
	while(binary>0){
		int digit=binary%10;
		binary/10;
		decimal+=digit*base;
		base*=2;
	}
	return decimal;
}
int main(){
	
}
